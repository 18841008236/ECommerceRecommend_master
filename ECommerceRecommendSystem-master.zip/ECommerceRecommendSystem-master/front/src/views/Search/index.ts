import Search from './Search.vue'
export { Search }