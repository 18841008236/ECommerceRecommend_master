import Login from "./Login/Login.vue"
import Home from "./Home/Home.vue"
import Detail from "./Detail/Detail.vue"
import Header from "./Header/Header.vue"
import Search from "./Search/Search.vue"
export { Login, Home, Detail, Header, Search }