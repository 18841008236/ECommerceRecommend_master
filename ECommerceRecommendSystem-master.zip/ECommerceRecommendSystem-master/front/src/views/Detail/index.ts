import Detail from './Detail.vue'
export { Detail }