import Home from './Home.vue'
export { Home }