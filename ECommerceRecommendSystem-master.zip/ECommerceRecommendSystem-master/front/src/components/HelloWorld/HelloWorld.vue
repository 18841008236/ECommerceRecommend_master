<template>
  <div class="hello">
    <h1>{{ msg }}</h1>
  </div>
</template>

<script src="./HelloWorld.ts" lang="ts" />

<style scoped lang="stylus">
@import url('./HelloWorld.stylus');
</style>
