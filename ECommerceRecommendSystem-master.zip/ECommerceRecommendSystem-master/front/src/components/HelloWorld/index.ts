import HelloWorld from './HelloWorld.vue'
export { HelloWorld }